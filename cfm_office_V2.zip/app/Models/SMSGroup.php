<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SMSGroup extends Model
{
    protected $table = 'sms_groups';
}
