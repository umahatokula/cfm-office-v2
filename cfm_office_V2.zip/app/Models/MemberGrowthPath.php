<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MemberGrowthPath extends Model
{
    //
}
