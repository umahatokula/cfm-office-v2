<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SalaryDetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
